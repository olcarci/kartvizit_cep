import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:kartvizit_cep/main.dart';
import 'package:kartvizit_cep/models/card_data.dart';

void main() {
  testWidgets('Elle giriş kişi kartını açar', (tester) async {
    await tester.pumpWidget(const KartvizitApp());

    // ListView's outer Scrollable is visited before nested text-field scrollers.
    Finder pageScroll() => find.descendant(
      of: find.byType(ListView),
      matching: find.byType(Scrollable),
    ).first;

    final manualEntry = find.text('Bilgileri elle gir');
    await tester.scrollUntilVisible(manualEntry, 200, scrollable: pageScroll());
    await tester.pumpAndSettle();
    await tester.tap(manualEntry);
    await tester.pumpAndSettle();
    expect(find.text('Kişi bilgilerini kontrol et'), findsOneWidget);
    expect(find.text('Ad soyad'), findsOneWidget);

    // Verify each field after scrolling it into view, even in a short viewport.
    final mobile = find.text('Cep telefonu');
    await tester.scrollUntilVisible(mobile, 150, scrollable: pageScroll());
    expect(mobile, findsOneWidget);
    final work = find.text('Sabit / iş telefonu');
    await tester.scrollUntilVisible(work, 150, scrollable: pageScroll());
    expect(work, findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Ana ekran telefon fotoğrafları ile uygulama arşivini ayırır', (tester) async {
    await tester.pumpWidget(const KartvizitApp());
    Finder pageScroll() => find.descendant(
      of: find.byType(ListView),
      matching: find.byType(Scrollable),
    ).first;
    final gallery = find.text('Kartvizit Galerisi');
    await tester.scrollUntilVisible(gallery, 200, scrollable: pageScroll());
    expect(find.text('Fotoğraflardan seç'), findsOneWidget);
    expect(gallery, findsOneWidget);
    expect(find.text('Galeriden seç'), findsNothing);
    expect(find.text('SMART CONTACT ENGINE'), findsOneWidget);
    expect(find.text('OCR'), findsOneWidget);
  });

  testWidgets('Galeri bilgileri rehbere eklemeden güncellenebilir', (tester) async {
    CardData? updated;
    await tester.pumpWidget(MaterialApp(home: EditPage(
      data: CardData(name: 'Ali Şahin'),
      onDataChanged: (data) async {
        updated = data;
      },
    )));

    await tester.enterText(find.widgetWithText(TextFormField, 'Şirket'), 'Eren Group');
    Finder pageScroll() => find.descendant(
      of: find.byType(ListView),
      matching: find.byType(Scrollable),
    ).first;
    final updateButton = find.text('Galeri bilgilerini güncelle');
    await tester.scrollUntilVisible(updateButton, 250, scrollable: pageScroll());
    await tester.tap(updateButton);
    await tester.pump();

    expect(updated?.name, 'Ali Şahin');
    expect(updated?.company, 'Eren Group');
    expect(find.text('Galeri bilgileri güncellendi.'), findsOneWidget);
  });
}
